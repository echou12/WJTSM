// app/dashboard/reports/page.tsx
import ReportsClient from '@/components/dashboard/ReportsClient'
export default function ReportsPage() {
  return <ReportsClient />
}
