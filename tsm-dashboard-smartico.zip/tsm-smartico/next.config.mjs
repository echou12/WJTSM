// next.config.mjs
import createNextIntlPlugin from 'next-intl/plugin'

const withNextIntl = createNextIntlPlugin('./i18n/request.ts')

/** @type {import('next').NextConfig} */
const nextConfig = {
  // FUTURE EXTENSION: Add image domains for player avatars
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: '**.supabase.co' },
      { protocol: 'https', hostname: 'avatars.githubusercontent.com' },
    ],
  },
  // Silence Prisma warnings in Next.js
  serverExternalPackages: ['@prisma/client', 'bcryptjs'],
}

export default withNextIntl(nextConfig)
