// i18n/request.ts
import { getRequestConfig } from 'next-intl/server'
import { cookies } from 'next/headers'

export default getRequestConfig(async () => {
  // Read locale from cookie (set by language switcher)
  const cookieStore = await cookies()
  const locale = cookieStore.get('locale')?.value || 'pt'

  const validLocales = ['pt', 'en', 'zh']
  const safeLocale = validLocales.includes(locale) ? locale : 'pt'

  return {
    locale: safeLocale,
    messages: (await import(`../messages/${safeLocale}.json`)).default,
  }
})
