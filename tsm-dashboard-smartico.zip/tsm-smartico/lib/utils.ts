// lib/utils.ts
import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Format currency (BRL default)
export function formatCurrency(
  amount: number,
  currency = 'BRL',
  locale = 'pt-BR'
): string {
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
  }).format(amount)
}

// Format number with thousands separator
export function formatNumber(n: number, locale = 'pt-BR'): string {
  return new Intl.NumberFormat(locale).format(n)
}

// Format date
export function formatDate(date: Date | string, locale = 'pt-BR'): string {
  return new Intl.DateTimeFormat(locale, {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  }).format(new Date(date))
}

// Format datetime
export function formatDateTime(date: Date | string, locale = 'pt-BR'): string {
  return new Intl.DateTimeFormat(locale, {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(date))
}

// Get initials from name
export function getInitials(name: string): string {
  return name
    .split(' ')
    .slice(0, 2)
    .map(n => n[0])
    .join('')
    .toUpperCase()
}

// Role badge colors
export function getRoleColor(role: string): string {
  const map: Record<string, string> = {
    superadmin: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    admin: 'bg-red-500/20 text-red-400 border-red-500/30',
    manager: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    consultant: 'bg-green-500/20 text-green-400 border-green-500/30',
  }
  return map[role] || 'bg-gray-500/20 text-gray-400 border-gray-500/30'
}

// Status badge colors
export function getStatusColor(status: string): string {
  const map: Record<string, string> = {
    active: 'bg-green-500/20 text-green-400 border-green-500/30',
    inactive: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
    vip: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    blacklisted: 'bg-red-500/20 text-red-400 border-red-500/30',
  }
  return map[status] || 'bg-gray-500/20 text-gray-400 border-gray-500/30'
}

// Check if user can access a role level
export function canAccess(userRole: string, requiredRole: string): boolean {
  const hierarchy: Record<string, number> = {
    superadmin: 4,
    admin: 3,
    manager: 2,
    consultant: 1,
  }
  return (hierarchy[userRole] || 0) >= (hierarchy[requiredRole] || 0)
}
