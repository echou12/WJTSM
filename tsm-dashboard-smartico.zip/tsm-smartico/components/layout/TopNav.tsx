// components/layout/TopNav.tsx
'use client'

import { useState } from 'react'
import { signOut } from 'next-auth/react'
import { Bell, LogOut, Settings, User, Globe, ChevronDown } from 'lucide-react'
import { useRouter } from 'next/navigation'
import type { SessionUser } from '@/types'
import { getRoleColor } from '@/lib/utils'

interface TopNavProps {
  user: SessionUser
}

const LOCALES = [
  { code: 'pt', label: 'Português', flag: '🇧🇷' },
  { code: 'en', label: 'English', flag: '🇺🇸' },
  { code: 'zh', label: '简体中文', flag: '🇨🇳' },
]

export default function TopNav({ user }: TopNavProps) {
  const router = useRouter()
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const [langMenuOpen, setLangMenuOpen] = useState(false)
  const [currentLocale, setCurrentLocale] = useState('pt')

  async function switchLocale(locale: string) {
    setCurrentLocale(locale)
    setLangMenuOpen(false)
    await fetch('/api/locale', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ locale }),
    })
    router.refresh()
  }

  async function handleLogout() {
    await signOut({ redirect: false })
    router.push('/login')
  }

  const currentLang = LOCALES.find(l => l.code === currentLocale) || LOCALES[0]

  return (
    <header className="h-16 bg-[#0f1623] border-b border-[#1e2d42] flex items-center justify-between px-6 flex-shrink-0">
      {/* Left: Page title area */}
      <div className="flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-sky-500 animate-pulse" />
        <span className="text-slate-400 text-sm">Sistema Online</span>
      </div>

      {/* Right: actions */}
      <div className="flex items-center gap-2">
        {/* Language switcher */}
        <div className="relative">
          <button
            onClick={() => { setLangMenuOpen(!langMenuOpen); setUserMenuOpen(false) }}
            className="flex items-center gap-2 px-3 py-2 rounded-lg text-slate-400
                       hover:text-white hover:bg-[#1a2535] transition-colors text-sm"
          >
            <Globe size={16} />
            <span>{currentLang.flag}</span>
            <ChevronDown size={14} />
          </button>

          {langMenuOpen && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setLangMenuOpen(false)} />
              <div className="absolute right-0 top-full mt-1 w-44 bg-[#111827] border border-[#1e2d42]
                              rounded-lg shadow-2xl z-20 py-1 overflow-hidden">
                {LOCALES.map(locale => (
                  <button
                    key={locale.code}
                    onClick={() => switchLocale(locale.code)}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors
                                ${currentLocale === locale.code
                                  ? 'text-sky-400 bg-sky-500/10'
                                  : 'text-slate-300 hover:text-white hover:bg-[#1a2535]'}`}
                  >
                    <span>{locale.flag}</span>
                    <span>{locale.label}</span>
                    {currentLocale === locale.code && (
                      <span className="ml-auto w-2 h-2 rounded-full bg-sky-400" />
                    )}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Notifications */}
        <button className="relative p-2 rounded-lg text-slate-400 hover:text-white
                           hover:bg-[#1a2535] transition-colors">
          <Bell size={18} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-sky-500 rounded-full" />
        </button>

        {/* User menu */}
        <div className="relative">
          <button
            onClick={() => { setUserMenuOpen(!userMenuOpen); setLangMenuOpen(false) }}
            className="flex items-center gap-2.5 pl-2 pr-3 py-1.5 rounded-lg
                       hover:bg-[#1a2535] transition-colors"
          >
            <div className="w-7 h-7 rounded-full bg-sky-500/20 border border-sky-500/30
                            flex items-center justify-center">
              <span className="text-sky-400 text-xs font-bold">
                {user.name?.charAt(0).toUpperCase()}
              </span>
            </div>
            <div className="text-left hidden sm:block">
              <p className="text-sm font-medium text-white leading-tight">{user.name}</p>
              <p className="text-xs text-slate-500 leading-tight capitalize">{user.role}</p>
            </div>
            <ChevronDown size={14} className="text-slate-500" />
          </button>

          {userMenuOpen && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setUserMenuOpen(false)} />
              <div className="absolute right-0 top-full mt-1 w-52 bg-[#111827] border border-[#1e2d42]
                              rounded-lg shadow-2xl z-20 py-1 overflow-hidden">
                {/* User info */}
                <div className="px-4 py-3 border-b border-[#1e2d42]">
                  <p className="text-sm font-medium text-white">{user.name}</p>
                  <p className="text-xs text-slate-500 truncate">{user.email}</p>
                  <span className={`mt-1 inline-block tsm-badge text-xs ${getRoleColor(user.role)}`}>
                    {user.role}
                  </span>
                </div>

                <button
                  onClick={() => { router.push('/dashboard/settings'); setUserMenuOpen(false) }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm
                             text-slate-300 hover:text-white hover:bg-[#1a2535] transition-colors"
                >
                  <Settings size={15} />
                  Configurações
                </button>

                <button
                  onClick={() => { router.push('/dashboard/settings'); setUserMenuOpen(false) }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm
                             text-slate-300 hover:text-white hover:bg-[#1a2535] transition-colors"
                >
                  <User size={15} />
                  Meu Perfil
                </button>

                <div className="border-t border-[#1e2d42] mt-1 pt-1">
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-3 px-4 py-2.5 text-sm
                               text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-colors"
                  >
                    <LogOut size={15} />
                    Sair
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  )
}
