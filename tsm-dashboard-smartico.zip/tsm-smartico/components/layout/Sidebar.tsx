// components/layout/Sidebar.tsx
'use client'

import { usePathname } from 'next/navigation'
import Link from 'next/link'
import {
  LayoutDashboard,
  Users,
  UserCircle,
  Group,
  BarChart3,
  Settings,
  ChevronRight,
  Gamepad2,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import type { SessionUser } from '@/types'

interface SidebarProps {
  user: SessionUser
}

interface NavItem {
  href: string
  label: string
  icon: React.ElementType
  roles?: string[]
  badge?: string
}

const navItems: NavItem[] = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/dashboard/consultants', label: 'Consultores', icon: UserCircle },
  { href: '/dashboard/players', label: 'Jogadores', icon: Gamepad2 },
  { href: '/dashboard/groups', label: 'Grupos', icon: Group },
  { href: '/dashboard/reports', label: 'Relatórios', icon: BarChart3 },
  {
    href: '/dashboard/users',
    label: 'Usuários',
    icon: Users,
    roles: ['superadmin', 'admin'],
  },
  { href: '/dashboard/settings', label: 'Configurações', icon: Settings },
]

// FUTURE EXTENSION: Add new nav items here
export default function Sidebar({ user }: SidebarProps) {
  const pathname = usePathname()

  const visibleItems = navItems.filter(item =>
    !item.roles || item.roles.includes(user.role)
  )

  return (
    <aside className="w-60 flex-shrink-0 flex flex-col bg-[#0f1623] border-r border-[#1e2d42]">
      {/* Logo */}
      <div className="h-16 flex items-center px-5 border-b border-[#1e2d42]">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-sky-500/20 border border-sky-500/30
                          flex items-center justify-center flex-shrink-0">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <text x="1" y="14" fontFamily="Arial" fontWeight="bold" fontSize="11" fill="#0ea5e9">T</text>
              <text x="7" y="14" fontFamily="Arial" fontWeight="bold" fontSize="9" fill="#38bdf8">SM</text>
            </svg>
          </div>
          <span className="text-white font-bold text-base tracking-wide">TSM</span>
        </div>
      </div>

      {/* Nav items */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {/* FUTURE EXTENSION: Add new pages here */}
        {visibleItems.map(item => {
          const Icon = item.icon
          const isActive = pathname === item.href ||
            (item.href !== '/dashboard' && pathname.startsWith(item.href))

          return (
            <Link key={item.href} href={item.href}>
              <div
                className={cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium',
                  'transition-all duration-200 cursor-pointer group',
                  isActive
                    ? 'text-white bg-[#1a2535] border-l-2 border-sky-500 pl-[10px]'
                    : 'text-slate-400 hover:text-white hover:bg-[#1a2535]'
                )}
              >
                <Icon
                  size={18}
                  className={cn(
                    'flex-shrink-0 transition-colors',
                    isActive ? 'text-sky-400' : 'text-slate-500 group-hover:text-slate-300'
                  )}
                />
                <span className="flex-1">{item.label}</span>
                {isActive && (
                  <ChevronRight size={14} className="text-sky-400 ml-auto" />
                )}
                {item.badge && (
                  <span className="bg-sky-500 text-white text-xs px-1.5 py-0.5 rounded-full">
                    {item.badge}
                  </span>
                )}
              </div>
            </Link>
          )
        })}
      </nav>

      {/* User info at bottom */}
      <div className="px-3 py-4 border-t border-[#1e2d42]">
        <div className="flex items-center gap-3 px-3 py-2.5">
          <div className="w-8 h-8 rounded-full bg-sky-500/20 border border-sky-500/30
                          flex items-center justify-center flex-shrink-0">
            <span className="text-sky-400 text-xs font-bold">
              {user.name?.charAt(0).toUpperCase()}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">{user.name}</p>
            <p className="text-xs text-slate-500 truncate capitalize">{user.role}</p>
          </div>
        </div>
      </div>
    </aside>
  )
}
