// components/dashboard/SettingsClient.tsx
'use client'

import { useState } from 'react'
import { Globe, Lock, User, Bell, CheckCircle, Save } from 'lucide-react'
import { useRouter } from 'next/navigation'
import type { SessionUser } from '@/types'

const LOCALES = [
  { code: 'pt', label: 'Português', flag: '🇧🇷', desc: 'Idioma padrão do sistema' },
  { code: 'en', label: 'English', flag: '🇺🇸', desc: 'Default system language' },
  { code: 'zh', label: '简体中文', flag: '🇨🇳', desc: '系统默认语言' },
]

export default function SettingsClient({ user }: { user: SessionUser }) {
  const router = useRouter()
  const [locale, setLocale] = useState('pt')
  const [saved, setSaved] = useState('')
  const [tab, setTab] = useState<'profile' | 'language' | 'security' | 'notifications'>('language')

  async function saveLocale(code: string) {
    setLocale(code)
    await fetch('/api/locale', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ locale: code }),
    })
    setSaved('Idioma atualizado com sucesso!')
    setTimeout(() => { setSaved(''); router.refresh() }, 1500)
  }

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold text-white">Configurações</h1>
        <p className="text-slate-500 text-sm mt-1">Gerencie suas preferências do sistema</p>
      </div>

      {saved && (
        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg px-4 py-3 text-emerald-400 text-sm flex items-center gap-2">
          <CheckCircle size={16} /> {saved}
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 bg-[#111827] border border-[#1e2d42] rounded-xl p-1.5">
        {([
          { key: 'language', label: 'Idioma', icon: Globe },
          { key: 'profile', label: 'Perfil', icon: User },
          { key: 'security', label: 'Segurança', icon: Lock },
          { key: 'notifications', label: 'Notificações', icon: Bell },
        ] as const).map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs font-medium transition-colors
              ${tab === t.key ? 'bg-sky-500 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            <t.icon size={14} /> {t.label}
          </button>
        ))}
      </div>

      {/* Language */}
      {tab === 'language' && (
        <div className="bg-[#111827] border border-[#1e2d42] rounded-xl p-6">
          <h3 className="text-sm font-semibold text-white mb-1">Idioma do Sistema</h3>
          <p className="text-xs text-slate-500 mb-5">Selecione o idioma para a interface do dashboard</p>
          <div className="space-y-3">
            {LOCALES.map(l => (
              <div
                key={l.code}
                onClick={() => saveLocale(l.code)}
                className={`flex items-center justify-between p-4 rounded-xl border-2 cursor-pointer transition-all
                  ${locale === l.code
                    ? 'border-sky-500 bg-sky-500/5'
                    : 'border-[#1e2d42] hover:border-[#2a3d55] bg-[#1a2535]/30'}`}
              >
                <div className="flex items-center gap-4">
                  <span className="text-2xl">{l.flag}</span>
                  <div>
                    <p className="font-medium text-white">{l.label}</p>
                    <p className="text-xs text-slate-500">{l.desc}</p>
                  </div>
                </div>
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center
                  ${locale === l.code ? 'border-sky-500 bg-sky-500' : 'border-[#1e2d42]'}`}>
                  {locale === l.code && <span className="w-2 h-2 bg-white rounded-full" />}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Profile */}
      {tab === 'profile' && (
        <div className="bg-[#111827] border border-[#1e2d42] rounded-xl p-6 space-y-5">
          <div>
            <h3 className="text-sm font-semibold text-white mb-4">Informações do Perfil</h3>
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-full bg-sky-500/10 border-2 border-sky-500/30
                              flex items-center justify-center text-sky-400 text-2xl font-bold">
                {user.name?.charAt(0).toUpperCase()}
              </div>
              <div>
                <p className="font-semibold text-white text-lg">{user.name}</p>
                <p className="text-slate-400 text-sm">{user.email}</p>
                <p className="text-xs text-sky-400 capitalize mt-0.5">{user.role}</p>
              </div>
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">Nome</label>
              <input defaultValue={user.name || ''} className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">E-mail</label>
              <input defaultValue={user.email || ''} type="email" className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500" />
            </div>
          </div>
          <button className="tsm-btn-primary">
            <Save size={15} /> Salvar Perfil
          </button>
        </div>
      )}

      {/* Security */}
      {tab === 'security' && (
        <div className="bg-[#111827] border border-[#1e2d42] rounded-xl p-6 space-y-5">
          <h3 className="text-sm font-semibold text-white mb-4">Segurança</h3>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1.5">Senha Atual</label>
            <input type="password" placeholder="••••••••" className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1.5">Nova Senha</label>
            <input type="password" placeholder="Mínimo 8 caracteres" className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1.5">Confirmar Nova Senha</label>
            <input type="password" placeholder="Repita a nova senha" className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500" />
          </div>
          <button className="tsm-btn-primary">
            <Lock size={15} /> Alterar Senha
          </button>
        </div>
      )}

      {/* Notifications */}
      {tab === 'notifications' && (
        <div className="bg-[#111827] border border-[#1e2d42] rounded-xl p-6 space-y-4">
          <h3 className="text-sm font-semibold text-white mb-4">Notificações</h3>
          {[
            { label: 'Novos jogadores cadastrados', desc: 'Receber alerta quando um novo jogador for adicionado' },
            { label: 'Transferências de alto valor', desc: 'Alertas para depósitos e saques acima de R$ 10.000' },
            { label: 'Jogadores na lista negra', desc: 'Notificação quando jogador for banido' },
          ].map((n, i) => (
            <div key={i} className="flex items-center justify-between py-3 border-b border-[#1e2d42]">
              <div>
                <p className="text-sm font-medium text-white">{n.label}</p>
                <p className="text-xs text-slate-500">{n.desc}</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" defaultChecked={i === 0} className="sr-only peer" />
                <div className="w-10 h-5 bg-[#1e2d42] peer-focus:outline-none rounded-full peer
                                peer-checked:after:translate-x-5 peer-checked:after:border-white
                                after:content-[''] after:absolute after:top-0.5 after:left-0.5
                                after:bg-white after:rounded-full after:h-4 after:w-4
                                after:transition-all peer-checked:bg-sky-500" />
              </label>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
