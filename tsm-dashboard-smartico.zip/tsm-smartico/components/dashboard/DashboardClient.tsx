// components/dashboard/DashboardClient.tsx
'use client'

import { useState } from 'react'
import {
  TrendingUp, TrendingDown, DollarSign, Users,
  UserPlus, Crown, ChevronDown, ChevronUp, Eye, BarChart2
} from 'lucide-react'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend
} from 'recharts'
import { formatCurrency, getStatusColor } from '@/lib/utils'
import type { DashboardStats, DashboardPlayerDetail, DashboardGroupSummary } from '@/types'

interface Props {
  stats: DashboardStats
  userName: string
}

// ─── STAT CARD ────────────────────────────────────────────────────────────────
function StatCard({
  label, value, sub, icon: Icon, color, trend
}: {
  label: string
  value: string
  sub?: string
  icon: React.ElementType
  color: string
  trend?: 'up' | 'down' | 'neutral'
}) {
  return (
    <div className="bg-[#111827] border border-[#1e2d42] rounded-xl p-5 flex items-start gap-4 hover:border-[#2a3d55] transition-colors">
      <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${color}`}>
        <Icon size={20} className="text-white" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-1">{label}</p>
        <p className="text-xl font-bold text-white truncate">{value}</p>
        {sub && (
          <p className={`text-xs mt-0.5 flex items-center gap-1
            ${trend === 'up' ? 'text-emerald-400' : trend === 'down' ? 'text-red-400' : 'text-slate-500'}`}>
            {trend === 'up' && <TrendingUp size={11} />}
            {trend === 'down' && <TrendingDown size={11} />}
            {sub}
          </p>
        )}
      </div>
    </div>
  )
}

// ─── PLAYER ROW ──────────────────────────────────────────────────────────────
function PlayerRow({ player, index }: { player: DashboardPlayerDetail; index: number }) {
  const net = player.deposit - player.withdrawal
  return (
    <tr className="border-b border-[#1e2d42]/50 hover:bg-[#1a2535]/30 transition-colors">
      <td className="px-4 py-3 text-slate-400 text-xs">{index + 1}</td>
      <td className="px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-[#1a2535] border border-[#1e2d42]
                          flex items-center justify-center text-xs font-bold text-sky-400">
            {player.name.charAt(0)}
          </div>
          <span className="text-sm font-medium text-white">{player.name}</span>
        </div>
      </td>
      <td className="px-4 py-3 text-slate-400 text-sm">{player.phone || '—'}</td>
      <td className="px-4 py-3">
        <span className={`tsm-badge ${getStatusColor(player.status)}`}>
          {player.status === 'vip' ? 'VIP' : player.status === 'active' ? 'Ativo' : player.status}
        </span>
      </td>
      <td className="px-4 py-3 text-emerald-400 text-sm font-medium">
        {player.deposit > 0 ? formatCurrency(player.deposit) : '—'}
      </td>
      <td className="px-4 py-3 text-red-400 text-sm font-medium">
        {player.withdrawal > 0 ? formatCurrency(player.withdrawal) : '—'}
      </td>
      <td className={`px-4 py-3 text-sm font-bold ${net >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
        {player.deposit > 0 || player.withdrawal > 0 ? formatCurrency(net) : '—'}
      </td>
      <td className="px-4 py-3 text-sky-400 text-sm">
        {player.houseProfit > 0 ? formatCurrency(player.houseProfit) : '—'}
      </td>
    </tr>
  )
}

// ─── VIP SECTION ──────────────────────────────────────────────────────────────
function VipSection({ vip }: { vip: DashboardStats['vip'] }) {
  const [tab, setTab] = useState<'with' | 'without'>('with')
  const [expanded, setExpanded] = useState(true)

  const withActivity = vip.players.filter(p => p.hasActivity)
  const withoutActivity = vip.players.filter(p => !p.hasActivity)
  const displayed = tab === 'with' ? withActivity : withoutActivity
  const totalNet = vip.deposits - vip.withdrawals

  return (
    <div className="bg-[#111827] border border-[#1e2d42] rounded-xl overflow-hidden">
      {/* Header */}
      <div
        className="flex items-center justify-between px-5 py-4 cursor-pointer hover:bg-[#1a2535]/30 transition-colors"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-yellow-500/10 border border-yellow-500/20
                          flex items-center justify-center">
            <Crown size={16} className="text-yellow-400" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white">Jogadores VIP</h3>
            <p className="text-xs text-slate-500">{vip.players.length} jogadores VIP</p>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <div className="text-right hidden sm:block">
            <p className="text-xs text-slate-500">Depósitos</p>
            <p className="text-sm font-bold text-emerald-400">{formatCurrency(vip.deposits)}</p>
          </div>
          <div className="text-right hidden sm:block">
            <p className="text-xs text-slate-500">Saques</p>
            <p className="text-sm font-bold text-red-400">{formatCurrency(vip.withdrawals)}</p>
          </div>
          <div className="text-right hidden sm:block">
            <p className="text-xs text-slate-500">Diferença</p>
            <p className={`text-sm font-bold ${totalNet >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {formatCurrency(totalNet)}
            </p>
          </div>
          {expanded ? <ChevronUp size={18} className="text-slate-400" /> : <ChevronDown size={18} className="text-slate-400" />}
        </div>
      </div>

      {expanded && (
        <>
          {/* Tabs */}
          <div className="flex border-t border-[#1e2d42]">
            <button
              onClick={() => setTab('with')}
              className={`flex-1 py-2.5 text-xs font-medium transition-colors
                ${tab === 'with'
                  ? 'text-sky-400 border-b-2 border-sky-500 bg-sky-500/5'
                  : 'text-slate-500 hover:text-slate-300'}`}
            >
              Com Movimentação ({withActivity.length})
            </button>
            <button
              onClick={() => setTab('without')}
              className={`flex-1 py-2.5 text-xs font-medium transition-colors
                ${tab === 'without'
                  ? 'text-slate-300 border-b-2 border-slate-500 bg-slate-500/5'
                  : 'text-slate-500 hover:text-slate-300'}`}
            >
              Sem Movimentação ({withoutActivity.length})
            </button>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#1e2d42]">
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider w-10">#</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Nome</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Telefone</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Depósito</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Saque</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Diferença</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Lucro (Casa)</th>
                </tr>
              </thead>
              <tbody>
                {displayed.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-8 text-slate-500 text-sm">
                      Nenhum jogador VIP nesta categoria hoje
                    </td>
                  </tr>
                ) : (
                  displayed.map((player, i) => (
                    <PlayerRow key={player.id} player={player} index={i} />
                  ))
                )}
              </tbody>
              {/* VIP subtotal */}
              {displayed.length > 0 && tab === 'with' && (
                <tfoot>
                  <tr className="bg-[#0f1623] border-t border-[#1e2d42]">
                    <td colSpan={4} className="px-4 py-3 text-xs font-bold text-slate-400 uppercase">
                      Subtotal VIP
                    </td>
                    <td className="px-4 py-3 text-emerald-400 font-bold text-sm">
                      {formatCurrency(vip.deposits)}
                    </td>
                    <td className="px-4 py-3 text-red-400 font-bold text-sm">
                      {formatCurrency(vip.withdrawals)}
                    </td>
                    <td className={`px-4 py-3 font-bold text-sm ${totalNet >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {formatCurrency(totalNet)}
                    </td>
                    <td className="px-4 py-3 text-sky-400 font-bold text-sm">
                      {formatCurrency(displayed.reduce((s, p) => s + p.houseProfit, 0))}
                    </td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </>
      )}
    </div>
  )
}

// ─── GROUP SECTION ────────────────────────────────────────────────────────────
function GroupSection({ group }: { group: DashboardGroupSummary }) {
  const [expanded, setExpanded] = useState(true)
  const [tab, setTab] = useState<'with' | 'without'>('with')

  const withActivity = group.players.filter(p => p.hasActivity)
  const withoutActivity = group.players.filter(p => !p.hasActivity)
  const displayed = tab === 'with' ? withActivity : withoutActivity

  return (
    <div className="bg-[#111827] border border-[#1e2d42] rounded-xl overflow-hidden">
      <div
        className="flex items-center justify-between px-5 py-4 cursor-pointer hover:bg-[#1a2535]/30"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20
                          flex items-center justify-center">
            <Users size={16} className="text-blue-400" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white">{group.groupName}</h3>
            <p className="text-xs text-slate-500">
              {group.consultant && <span>Consultor: {group.consultant} · </span>}
              {group.players.length} jogadores
            </p>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <div className="text-right hidden sm:block">
            <p className="text-xs text-slate-500">Depósitos</p>
            <p className="text-sm font-bold text-emerald-400">{formatCurrency(group.deposits)}</p>
          </div>
          <div className="text-right hidden sm:block">
            <p className="text-xs text-slate-500">Saques</p>
            <p className="text-sm font-bold text-red-400">{formatCurrency(group.withdrawals)}</p>
          </div>
          <div className="text-right hidden sm:block">
            <p className="text-xs text-slate-500">Diferença</p>
            <p className={`text-sm font-bold ${group.net >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {formatCurrency(group.net)}
            </p>
          </div>
          {expanded ? <ChevronUp size={18} className="text-slate-400" /> : <ChevronDown size={18} className="text-slate-400" />}
        </div>
      </div>

      {expanded && (
        <>
          <div className="flex border-t border-[#1e2d42]">
            <button
              onClick={() => setTab('with')}
              className={`flex-1 py-2.5 text-xs font-medium transition-colors
                ${tab === 'with' ? 'text-sky-400 border-b-2 border-sky-500 bg-sky-500/5' : 'text-slate-500 hover:text-slate-300'}`}
            >
              Com Movimentação ({withActivity.length})
            </button>
            <button
              onClick={() => setTab('without')}
              className={`flex-1 py-2.5 text-xs font-medium transition-colors
                ${tab === 'without' ? 'text-slate-300 border-b-2 border-slate-500 bg-slate-500/5' : 'text-slate-500 hover:text-slate-300'}`}
            >
              Sem Movimentação ({withoutActivity.length})
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#1e2d42]">
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider w-10">#</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Nome</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Telefone</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Depósito</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Saque</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Diferença</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Lucro (Casa)</th>
                </tr>
              </thead>
              <tbody>
                {displayed.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-8 text-slate-500 text-sm">
                      Nenhum jogador nesta categoria
                    </td>
                  </tr>
                ) : (
                  displayed.map((player, i) => (
                    <PlayerRow key={player.id} player={player} index={i} />
                  ))
                )}
              </tbody>
              {displayed.length > 0 && tab === 'with' && (
                <tfoot>
                  <tr className="bg-[#0f1623] border-t border-[#1e2d42]">
                    <td colSpan={4} className="px-4 py-3 text-xs font-bold text-slate-400 uppercase">
                      Subtotal {group.groupName}
                    </td>
                    <td className="px-4 py-3 text-emerald-400 font-bold text-sm">
                      {formatCurrency(group.deposits)}
                    </td>
                    <td className="px-4 py-3 text-red-400 font-bold text-sm">
                      {formatCurrency(group.withdrawals)}
                    </td>
                    <td className={`px-4 py-3 font-bold text-sm ${group.net >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {formatCurrency(group.net)}
                    </td>
                    <td className="px-4 py-3 text-sky-400 font-bold text-sm">
                      {formatCurrency(displayed.reduce((s, p) => s + p.houseProfit, 0))}
                    </td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </>
      )}
    </div>
  )
}

// ─── CUSTOM CHART TOOLTIP ────────────────────────────────────────────────────
function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-[#1a2535] border border-[#1e2d42] rounded-lg px-4 py-3 shadow-xl">
      <p className="text-xs font-bold text-white mb-2">{label}</p>
      {payload.map((entry: any) => (
        <p key={entry.name} className="text-xs" style={{ color: entry.color }}>
          {entry.name}: {formatCurrency(entry.value)}
        </p>
      ))}
    </div>
  )
}

// ─── MAIN DASHBOARD ───────────────────────────────────────────────────────────
export default function DashboardClient({ stats, userName }: Props) {
  const { today, vip, groups, weekly } = stats

  // Grand totals
  const grandDeposits = today.totalDeposits
  const grandWithdrawals = today.totalWithdrawals
  const grandNet = grandDeposits - grandWithdrawals

  return (
    <div className="space-y-6 max-w-[1400px]">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Dashboard</h1>
        <p className="text-slate-500 text-sm mt-1">
          Bem-vindo, <span className="text-sky-400 font-medium">{userName}</span> · Dados de hoje
        </p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard
          label="Total Depósitos"
          value={formatCurrency(today.totalDeposits)}
          icon={TrendingUp}
          color="bg-emerald-500/20"
          trend="up"
          sub="Hoje"
        />
        <StatCard
          label="Total Saques"
          value={formatCurrency(today.totalWithdrawals)}
          icon={TrendingDown}
          color="bg-red-500/20"
          trend="down"
          sub="Hoje"
        />
        <StatCard
          label="Saldo Líquido"
          value={formatCurrency(today.netBalance)}
          icon={DollarSign}
          color="bg-sky-500/20"
          trend={today.netBalance >= 0 ? 'up' : 'down'}
          sub="Depósitos − Saques"
        />
        <StatCard
          label="Lucro da Casa"
          value={formatCurrency(today.houseProfit)}
          icon={BarChart2}
          color="bg-purple-500/20"
          trend="up"
          sub="Resultado operacional"
        />
        <StatCard
          label="Jogadores Ativos"
          value={String(today.activePlayers)}
          icon={Users}
          color="bg-blue-500/20"
          sub="Com movimentação hoje"
        />
        <StatCard
          label="Novos Jogadores"
          value={String(today.newPlayers)}
          icon={UserPlus}
          color="bg-orange-500/20"
          sub="Cadastros hoje"
        />
      </div>

      {/* Weekly chart */}
      <div className="bg-[#111827] border border-[#1e2d42] rounded-xl p-5">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="text-sm font-semibold text-white">Visão Semanal</h3>
            <p className="text-xs text-slate-500">Depósitos vs Saques — últimos 7 dias</p>
          </div>
          <div className="flex items-center gap-4 text-xs">
            <span className="flex items-center gap-1.5 text-slate-400">
              <span className="w-3 h-3 rounded-sm bg-emerald-500 inline-block" /> Depósitos
            </span>
            <span className="flex items-center gap-1.5 text-slate-400">
              <span className="w-3 h-3 rounded-sm bg-red-500 inline-block" /> Saques
            </span>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={weekly} barSize={24} barGap={4}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e2d42" vertical={false} />
            <XAxis dataKey="day" stroke="#64748b" tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis stroke="#64748b" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false}
              tickFormatter={v => `R$${(v / 1000).toFixed(0)}k`} />
            <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
            <Bar dataKey="deposits" name="Depósitos" fill="#22c55e" radius={[4, 4, 0, 0]} />
            <Bar dataKey="withdrawals" name="Saques" fill="#ef4444" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* VIP Section */}
      <VipSection vip={vip} />

      {/* Group sections */}
      {groups.map((group, i) => (
        <GroupSection key={i} group={group} />
      ))}

      {/* Grand total row */}
      <div className="bg-[#0f1623] border border-sky-500/20 rounded-xl overflow-hidden">
        <div className="px-5 py-3 border-b border-[#1e2d42]">
          <h3 className="text-sm font-bold text-sky-400 uppercase tracking-wider">
            Total Geral — Todos os Jogadores
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#1e2d42]">
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Categoria</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Total Depósitos</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Total Saques</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Diferença Final</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-[#1e2d42]/50">
                <td className="px-4 py-3 text-yellow-400 font-medium flex items-center gap-2">
                  <Crown size={14} /> VIP
                </td>
                <td className="px-4 py-3 text-emerald-400 font-semibold">{formatCurrency(vip.deposits)}</td>
                <td className="px-4 py-3 text-red-400 font-semibold">{formatCurrency(vip.withdrawals)}</td>
                <td className={`px-4 py-3 font-bold ${vip.deposits - vip.withdrawals >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {formatCurrency(vip.deposits - vip.withdrawals)}
                </td>
              </tr>
              {groups.map((g, i) => (
                <tr key={i} className="border-b border-[#1e2d42]/50">
                  <td className="px-4 py-3 text-blue-400 font-medium flex items-center gap-2">
                    <Users size={14} /> {g.groupName}
                  </td>
                  <td className="px-4 py-3 text-emerald-400 font-semibold">{formatCurrency(g.deposits)}</td>
                  <td className="px-4 py-3 text-red-400 font-semibold">{formatCurrency(g.withdrawals)}</td>
                  <td className={`px-4 py-3 font-bold ${g.net >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {formatCurrency(g.net)}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-sky-500/5 border-t-2 border-sky-500/30">
                <td className="px-4 py-4 text-white font-bold text-sm uppercase tracking-wider">
                  Total Final
                </td>
                <td className="px-4 py-4 text-emerald-400 font-bold text-base">
                  {formatCurrency(grandDeposits)}
                </td>
                <td className="px-4 py-4 text-red-400 font-bold text-base">
                  {formatCurrency(grandWithdrawals)}
                </td>
                <td className={`px-4 py-4 font-bold text-base ${grandNet >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {formatCurrency(grandNet)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  )
}
