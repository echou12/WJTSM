// components/dashboard/ConsultantsClient.tsx
'use client'

import { useState } from 'react'
import { Users, TrendingUp, Crown, Plus, Eye, Pencil, Search, BarChart2 } from 'lucide-react'
import { formatCurrency, getRoleColor } from '@/lib/utils'
import { mockUsers, mockPlayers } from '@/lib/mock-data'

export default function ConsultantsClient() {
  const [search, setSearch] = useState('')

  const consultants = mockUsers.filter(u => ['consultant', 'manager'].includes(u.role))

  const enriched = consultants.map(c => {
    const myPlayers = mockPlayers.filter(p => p.consultant === c.name)
    const totalDeposits = myPlayers.reduce((s, p) => s + (p.deposit || 0), 0)
    const totalWithdrawals = myPlayers.reduce((s, p) => s + (p.withdrawal || 0), 0)
    const vipCount = myPlayers.filter(p => p.status === 'vip').length
    return { ...c, playerCount: myPlayers.length, totalDeposits, totalWithdrawals, vipCount, net: totalDeposits - totalWithdrawals }
  })

  const filtered = enriched.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.email.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="space-y-6 max-w-6xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Consultores</h1>
          <p className="text-slate-500 text-sm mt-1">{consultants.length} consultores ativos</p>
        </div>
        <button className="tsm-btn-primary">
          <Plus size={16} /> Adicionar Consultor
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-[#111827] border border-[#1e2d42] rounded-xl p-5">
          <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Total Consultores</p>
          <p className="text-3xl font-bold text-white">{consultants.length}</p>
        </div>
        <div className="bg-[#111827] border border-[#1e2d42] rounded-xl p-5">
          <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Total Jogadores</p>
          <p className="text-3xl font-bold text-white">{enriched.reduce((s, c) => s + c.playerCount, 0)}</p>
        </div>
        <div className="bg-[#111827] border border-[#1e2d42] rounded-xl p-5">
          <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Volume Total</p>
          <p className="text-3xl font-bold text-emerald-400">
            {formatCurrency(enriched.reduce((s, c) => s + c.totalDeposits, 0))}
          </p>
        </div>
      </div>

      {/* Table */}
      <div className="bg-[#111827] border border-[#1e2d42] rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#1e2d42]">
          <div className="relative w-60">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar consultores..."
              className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg pl-9 pr-3 py-2
                         text-sm text-white placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#1e2d42]">
                <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Consultor</th>
                <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Função</th>
                <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Jogadores</th>
                <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">VIPs</th>
                <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Depósitos</th>
                <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Saques</th>
                <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Diferença</th>
                <th className="px-5 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => (
                <tr key={c.id} className="border-b border-[#1e2d42]/50 hover:bg-[#1a2535]/30 transition-colors">
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-[#1a2535] border border-[#1e2d42]
                                      flex items-center justify-center text-sky-400 font-bold text-sm">
                        {c.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-medium text-white">{c.name}</p>
                        <p className="text-xs text-slate-500">{c.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-4">
                    <span className={`tsm-badge ${getRoleColor(c.role)}`}>{c.role}</span>
                  </td>
                  <td className="px-5 py-4">
                    <span className="flex items-center gap-1.5 text-slate-300">
                      <Users size={14} className="text-slate-500" /> {c.playerCount}
                    </span>
                  </td>
                  <td className="px-5 py-4">
                    <span className="flex items-center gap-1.5 text-yellow-400 font-medium">
                      <Crown size={14} /> {c.vipCount}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-emerald-400 font-medium">{formatCurrency(c.totalDeposits)}</td>
                  <td className="px-5 py-4 text-red-400 font-medium">{formatCurrency(c.totalWithdrawals)}</td>
                  <td className={`px-5 py-4 font-bold ${c.net >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {formatCurrency(c.net)}
                  </td>
                  <td className="px-5 py-4">
                    <div className="flex items-center justify-end gap-1.5">
                      <button className="p-1.5 rounded-lg text-slate-400 hover:text-sky-400 hover:bg-sky-500/10 transition-colors">
                        <Eye size={15} />
                      </button>
                      <button className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 transition-colors">
                        <Pencil size={15} />
                      </button>
                      <button className="p-1.5 rounded-lg text-slate-400 hover:text-purple-400 hover:bg-purple-500/10 transition-colors">
                        <BarChart2 size={15} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
