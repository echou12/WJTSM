// components/dashboard/GroupsClient.tsx
'use client'

import { useState } from 'react'
import { Plus, Eye, Pencil, Trash2, Search, Users, TrendingUp, TrendingDown, ChevronDown, ChevronUp } from 'lucide-react'
import { formatCurrency } from '@/lib/utils'
import { mockGroups, mockPlayers } from '@/lib/mock-data'

export default function GroupsClient() {
  const [search, setSearch] = useState('')
  const [expanded, setExpanded] = useState<string | null>(null)
  const [success, setSuccess] = useState('')

  const filtered = mockGroups.filter(g =>
    g.name.toLowerCase().includes(search.toLowerCase())
  )

  const getGroupPlayers = (groupName: string) =>
    mockPlayers.filter(p => p.groupName === groupName)

  return (
    <div className="space-y-6 max-w-6xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Grupos</h1>
          <p className="text-slate-500 text-sm mt-1">{mockGroups.length} grupos cadastrados</p>
        </div>
        <button className="tsm-btn-primary">
          <Plus size={16} /> Adicionar Grupo
        </button>
      </div>

      {success && (
        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg px-4 py-3 text-emerald-400 text-sm">
          {success}
        </div>
      )}

      {/* Search */}
      <div className="relative w-64">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Buscar grupos..."
          className="w-full bg-[#111827] border border-[#1e2d42] rounded-lg pl-9 pr-3 py-2
                     text-sm text-white placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
        />
      </div>

      {/* Groups list */}
      <div className="space-y-4">
        {filtered.map(group => {
          const players = getGroupPlayers(group.name)
          const isExpanded = expanded === group.id
          const net = group.totalDeposits - group.totalWithdrawals

          return (
            <div key={group.id} className="bg-[#111827] border border-[#1e2d42] rounded-xl overflow-hidden">
              {/* Group header */}
              <div
                className="flex items-center justify-between px-5 py-4 cursor-pointer hover:bg-[#1a2535]/30"
                onClick={() => setExpanded(isExpanded ? null : group.id)}
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/20
                                  flex items-center justify-center">
                    <Users size={18} className="text-sky-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white">{group.name}</h3>
                    <p className="text-xs text-slate-500">
                      Consultor: {group.consultant} · {group.playerCount} jogadores
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-6">
                  <div className="text-right hidden sm:block">
                    <p className="text-xs text-slate-500">Depósitos</p>
                    <p className="text-sm font-bold text-emerald-400">{formatCurrency(group.totalDeposits)}</p>
                  </div>
                  <div className="text-right hidden sm:block">
                    <p className="text-xs text-slate-500">Saques</p>
                    <p className="text-sm font-bold text-red-400">{formatCurrency(group.totalWithdrawals)}</p>
                  </div>
                  <div className="text-right hidden sm:block">
                    <p className="text-xs text-slate-500">Diferença</p>
                    <p className={`text-sm font-bold ${net >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {formatCurrency(net)}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={e => { e.stopPropagation() }}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 transition-colors"
                    >
                      <Pencil size={14} />
                    </button>
                    <button
                      onClick={e => { e.stopPropagation() }}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                    >
                      <Trash2 size={14} />
                    </button>
                    {isExpanded
                      ? <ChevronUp size={18} className="text-slate-400 ml-2" />
                      : <ChevronDown size={18} className="text-slate-400 ml-2" />
                    }
                  </div>
                </div>
              </div>

              {/* Expanded players list */}
              {isExpanded && (
                <div className="border-t border-[#1e2d42]">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-[#1e2d42]">
                        <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Jogador</th>
                        <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Telefone</th>
                        <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                        <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Depósito</th>
                        <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Saque</th>
                      </tr>
                    </thead>
                    <tbody>
                      {players.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="text-center py-6 text-slate-500 text-sm">
                            Nenhum jogador neste grupo
                          </td>
                        </tr>
                      ) : (
                        players.map(p => (
                          <tr key={p.id} className="border-b border-[#1e2d42]/30 hover:bg-[#1a2535]/30">
                            <td className="px-5 py-3 font-medium text-white">{p.name}</td>
                            <td className="px-5 py-3 text-slate-400">{p.phone || '—'}</td>
                            <td className="px-5 py-3">
                              <span className="tsm-badge bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-xs">
                                {p.status}
                              </span>
                            </td>
                            <td className="px-5 py-3 text-emerald-400 font-medium">
                              {p.deposit > 0 ? formatCurrency(p.deposit) : '—'}
                            </td>
                            <td className="px-5 py-3 text-red-400 font-medium">
                              {p.withdrawal > 0 ? formatCurrency(p.withdrawal) : '—'}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
