// components/dashboard/UsersClient.tsx
'use client'

import { useState, useEffect, useCallback } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import {
  Plus, Pencil, Trash2, Loader2, X, Search,
  Shield, User, CheckCircle, XCircle, RefreshCw
} from 'lucide-react'
import { formatDate, getRoleColor } from '@/lib/utils'
import type { UserRow, SessionUser } from '@/types'
import { UserRole } from '@prisma/client'

const userSchema = z.object({
  name: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres'),
  email: z.string().email('E-mail inválido'),
  password: z.string().min(8, 'Senha deve ter pelo menos 8 caracteres').optional().or(z.literal('')),
  role: z.nativeEnum(UserRole),
  isActive: z.boolean().optional(),
})

type UserForm = z.infer<typeof userSchema>

interface Props {
  currentUser: SessionUser
}

const ROLES = [
  { value: 'superadmin', label: 'Super Admin', color: 'text-purple-400' },
  { value: 'admin', label: 'Administrador', color: 'text-red-400' },
  { value: 'manager', label: 'Gerente', color: 'text-blue-400' },
  { value: 'consultant', label: 'Consultor', color: 'text-green-400' },
]

export default function UsersClient({ currentUser }: Props) {
  const [users, setUsers] = useState<UserRow[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [modalOpen, setModalOpen] = useState(false)
  const [editUser, setEditUser] = useState<UserRow | null>(null)
  const [deleteConfirm, setDeleteConfirm] = useState<UserRow | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm<UserForm>({
    resolver: zodResolver(userSchema),
    defaultValues: { role: UserRole.consultant, isActive: true },
  })

  const fetchUsers = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/users')
      const json = await res.json()
      setUsers(json.data || [])
    } catch {
      setError('Erro ao carregar usuários')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchUsers() }, [fetchUsers])

  function openCreate() {
    setEditUser(null)
    reset({ role: UserRole.consultant, isActive: true, name: '', email: '', password: '' })
    setModalOpen(true)
    setError('')
  }

  function openEdit(user: UserRow) {
    setEditUser(user)
    reset({
      name: user.name,
      email: user.email,
      role: user.role,
      isActive: user.isActive,
      password: '',
    })
    setModalOpen(true)
    setError('')
  }

  async function onSubmit(data: UserForm) {
    setSubmitting(true)
    setError('')
    try {
      const body: Record<string, unknown> = {
        name: data.name,
        email: data.email,
        role: data.role,
        isActive: data.isActive,
      }
      if (data.password) body.password = data.password

      const url = editUser ? `/api/users/${editUser.id}` : '/api/users'
      const method = editUser ? 'PATCH' : 'POST'

      if (!editUser && !data.password) {
        setError('Senha é obrigatória para novos usuários')
        return
      }

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })

      const json = await res.json()
      if (!res.ok) {
        setError(json.error || 'Erro ao salvar usuário')
        return
      }

      setSuccess(editUser ? 'Usuário atualizado!' : 'Usuário criado!')
      setModalOpen(false)
      fetchUsers()
      setTimeout(() => setSuccess(''), 3000)
    } catch {
      setError('Erro inesperado')
    } finally {
      setSubmitting(false)
    }
  }

  async function handleDelete(user: UserRow) {
    try {
      const res = await fetch(`/api/users/${user.id}`, { method: 'DELETE' })
      if (!res.ok) {
        const json = await res.json()
        setError(json.error || 'Erro ao excluir')
        return
      }
      setSuccess('Usuário excluído!')
      setDeleteConfirm(null)
      fetchUsers()
      setTimeout(() => setSuccess(''), 3000)
    } catch {
      setError('Erro ao excluir usuário')
    }
  }

  const filtered = users.filter(u =>
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="space-y-6 max-w-6xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Usuários</h1>
          <p className="text-slate-500 text-sm mt-1">Gerencie contas de acesso ao sistema</p>
        </div>
        <button onClick={openCreate} className="tsm-btn-primary">
          <Plus size={16} />
          Adicionar Usuário
        </button>
      </div>

      {/* Feedback */}
      {success && (
        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg px-4 py-3 text-emerald-400 text-sm flex items-center gap-2">
          <CheckCircle size={16} /> {success}
        </div>
      )}
      {error && !modalOpen && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-3 text-red-400 text-sm flex items-center gap-2">
          <XCircle size={16} /> {error}
        </div>
      )}

      {/* Table card */}
      <div className="bg-[#111827] border border-[#1e2d42] rounded-xl overflow-hidden">
        {/* Table toolbar */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#1e2d42]">
          <div className="relative w-64">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar usuários..."
              className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg pl-9 pr-3 py-2
                         text-sm text-white placeholder:text-slate-500 focus:outline-none
                         focus:ring-1 focus:ring-sky-500"
            />
          </div>
          <button onClick={fetchUsers} className="tsm-btn-ghost">
            <RefreshCw size={15} />
            Atualizar
          </button>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#1e2d42]">
                <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Usuário</th>
                <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Função</th>
                <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Criado em</th>
                <th className="px-5 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Ações</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={5} className="text-center py-12">
                    <Loader2 size={24} className="animate-spin text-sky-500 mx-auto" />
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={5} className="text-center py-12 text-slate-500">
                    Nenhum usuário encontrado
                  </td>
                </tr>
              ) : (
                filtered.map(user => (
                  <tr key={user.id} className="border-b border-[#1e2d42]/50 hover:bg-[#1a2535]/30 transition-colors">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-[#1a2535] border border-[#1e2d42]
                                        flex items-center justify-center text-sky-400 text-sm font-bold flex-shrink-0">
                          {user.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-medium text-white">{user.name}</p>
                          <p className="text-xs text-slate-500">{user.email}</p>
                        </div>
                        {user.id === currentUser.id && (
                          <span className="tsm-badge bg-sky-500/10 text-sky-400 border-sky-500/20 text-xs">Você</span>
                        )}
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`tsm-badge ${getRoleColor(user.role)}`}>
                        <Shield size={10} className="mr-1" />
                        {ROLES.find(r => r.value === user.role)?.label || user.role}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      {user.isActive ? (
                        <span className="tsm-badge bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                          <CheckCircle size={11} className="mr-1" /> Ativo
                        </span>
                      ) : (
                        <span className="tsm-badge bg-slate-500/10 text-slate-400 border-slate-500/20">
                          <XCircle size={11} className="mr-1" /> Inativo
                        </span>
                      )}
                    </td>
                    <td className="px-5 py-3.5 text-slate-400 text-sm">
                      {formatDate(user.createdAt)}
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => openEdit(user)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-sky-400 hover:bg-sky-500/10 transition-colors"
                          title="Editar"
                        >
                          <Pencil size={15} />
                        </button>
                        {currentUser.role === 'superadmin' && user.id !== currentUser.id && (
                          <button
                            onClick={() => setDeleteConfirm(user)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                            title="Excluir"
                          >
                            <Trash2 size={15} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-[#1e2d42] text-xs text-slate-500">
          {filtered.length} usuário(s) encontrado(s)
        </div>
      </div>

      {/* ── CREATE/EDIT MODAL ─────────────────────────────────────────────────── */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setModalOpen(false)} />
          <div className="relative bg-[#111827] border border-[#1e2d42] rounded-2xl w-full max-w-md shadow-2xl">
            {/* Modal header */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-[#1e2d42]">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-sky-500/10 border border-sky-500/20
                                flex items-center justify-center">
                  <User size={16} className="text-sky-400" />
                </div>
                <h2 className="text-base font-semibold text-white">
                  {editUser ? 'Editar Usuário' : 'Novo Usuário'}
                </h2>
              </div>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-500 hover:text-white transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal body */}
            <form onSubmit={handleSubmit(onSubmit)} className="px-6 py-5 space-y-4">
              {error && (
                <div className="bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-3 text-red-400 text-sm">
                  {error}
                </div>
              )}

              {/* Name */}
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1.5">Nome</label>
                <input
                  {...register('name')}
                  placeholder="Nome completo"
                  className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg px-3 py-2.5
                             text-sm text-white placeholder:text-slate-500 focus:outline-none
                             focus:ring-2 focus:ring-sky-500"
                />
                {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name.message}</p>}
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1.5">E-mail</label>
                <input
                  {...register('email')}
                  type="email"
                  placeholder="email@dominio.com"
                  className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg px-3 py-2.5
                             text-sm text-white placeholder:text-slate-500 focus:outline-none
                             focus:ring-2 focus:ring-sky-500"
                />
                {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email.message}</p>}
              </div>

              {/* Password */}
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1.5">
                  Senha {editUser && <span className="text-slate-500 font-normal">(deixe em branco para manter)</span>}
                </label>
                <input
                  {...register('password')}
                  type="password"
                  placeholder={editUser ? '••••••••' : 'Mínimo 8 caracteres'}
                  className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg px-3 py-2.5
                             text-sm text-white placeholder:text-slate-500 focus:outline-none
                             focus:ring-2 focus:ring-sky-500"
                />
                {errors.password && <p className="text-red-400 text-xs mt-1">{errors.password.message}</p>}
              </div>

              {/* Role */}
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1.5">Função</label>
                <select
                  {...register('role')}
                  className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg px-3 py-2.5
                             text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                >
                  {ROLES.filter(r =>
                    currentUser.role === 'superadmin' || r.value !== 'superadmin'
                  ).map(r => (
                    <option key={r.value} value={r.value}>{r.label}</option>
                  ))}
                </select>
              </div>

              {/* Active toggle (edit only) */}
              {editUser && (
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-slate-300">Usuário Ativo</label>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      {...register('isActive')}
                      className="sr-only peer"
                    />
                    <div className="w-10 h-5 bg-[#1e2d42] peer-focus:outline-none rounded-full peer
                                    peer-checked:after:translate-x-5 peer-checked:after:border-white
                                    after:content-[''] after:absolute after:top-0.5 after:left-0.5
                                    after:bg-white after:rounded-full after:h-4 after:w-4
                                    after:transition-all peer-checked:bg-sky-500" />
                  </label>
                </div>
              )}

              {/* Footer */}
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="flex-1 bg-[#1a2535] hover:bg-[#243044] text-slate-300 font-medium
                             py-2.5 rounded-lg transition-colors text-sm"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 bg-sky-500 hover:bg-sky-600 disabled:opacity-50 text-white
                             font-medium py-2.5 rounded-lg transition-colors text-sm
                             flex items-center justify-center gap-2"
                >
                  {submitting ? <Loader2 size={16} className="animate-spin" /> : null}
                  {editUser ? 'Salvar' : 'Criar Usuário'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ── DELETE CONFIRM MODAL ──────────────────────────────────────────────── */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setDeleteConfirm(null)} />
          <div className="relative bg-[#111827] border border-red-500/20 rounded-2xl w-full max-w-sm shadow-2xl p-6 text-center">
            <div className="w-12 h-12 rounded-full bg-red-500/10 border border-red-500/20
                            flex items-center justify-center mx-auto mb-4">
              <Trash2 size={20} className="text-red-400" />
            </div>
            <h3 className="text-base font-semibold text-white mb-2">Excluir Usuário</h3>
            <p className="text-slate-400 text-sm mb-6">
              Tem certeza que deseja excluir <strong className="text-white">{deleteConfirm.name}</strong>?
              Esta ação não pode ser desfeita.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setDeleteConfirm(null)}
                className="flex-1 bg-[#1a2535] hover:bg-[#243044] text-slate-300 font-medium py-2.5 rounded-lg transition-colors text-sm"
              >
                Cancelar
              </button>
              <button
                onClick={() => handleDelete(deleteConfirm)}
                className="flex-1 bg-red-500 hover:bg-red-600 text-white font-medium py-2.5 rounded-lg transition-colors text-sm"
              >
                Excluir
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
