// components/dashboard/PlayersClient.tsx
'use client'

import { useState, useEffect, useCallback } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import {
  Plus, Eye, Pencil, Trash2, Loader2, X, Search,
  Ban, Settings2, Crown, Users, Phone, CheckCircle,
  XCircle, RefreshCw, AlertTriangle, FileText
} from 'lucide-react'
import { formatCurrency, formatDateTime, getStatusColor } from '@/lib/utils'
import { mockPlayers, mockGroups, mockUsers } from '@/lib/mock-data'

// Column definitions
const ALL_COLUMNS = [
  { key: 'name', label: 'Nome', always: true },
  { key: 'phone', label: 'Telefone', default: true },
  { key: 'status', label: 'Status', default: true },
  { key: 'vipLevel', label: 'Nível VIP', default: true },
  { key: 'group', label: 'Grupo', default: true },
  { key: 'consultant', label: 'Consultor', default: true },
  { key: 'deposit', label: 'Depósito', default: true },
  { key: 'withdrawal', label: 'Saque', default: true },
  { key: 'blacklist', label: 'Blacklist', default: false },
]

const STATUS_OPTIONS = [
  { value: '', label: 'Todos os status' },
  { value: 'active', label: 'Ativo' },
  { value: 'vip', label: 'VIP' },
  { value: 'inactive', label: 'Inativo' },
  { value: 'blacklisted', label: 'Banido' },
]

const playerSchema = z.object({
  name: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres'),
  phone: z.string().optional(),
  email: z.string().email().optional().or(z.literal('')),
  status: z.string().optional(),
  vipLevel: z.number().int().min(0).max(10).optional(),
  groupId: z.string().optional(),
  consultantId: z.string().optional(),
  notes: z.string().optional(),
})

type PlayerForm = z.infer<typeof playerSchema>

// ─── STATUS BADGE ────────────────────────────────────────────────────────────
function StatusBadge({ status }: { status: string }) {
  const labels: Record<string, string> = {
    active: 'Ativo', vip: 'VIP', inactive: 'Inativo', blacklisted: 'Banido'
  }
  return (
    <span className={`tsm-badge ${getStatusColor(status)}`}>
      {status === 'vip' && <Crown size={10} className="mr-1" />}
      {status === 'blacklisted' && <Ban size={10} className="mr-1" />}
      {labels[status] || status}
    </span>
  )
}

// ─── PLAYER DETAIL MODAL ─────────────────────────────────────────────────────
function PlayerDetailModal({
  player,
  onClose,
  onBlacklist
}: {
  player: any
  onClose: () => void
  onBlacklist: (p: any) => void
}) {
  const [tab, setTab] = useState<'in' | 'out'>('in')

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-[#111827] border border-[#1e2d42] rounded-2xl w-full max-w-2xl shadow-2xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#1e2d42] flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-sky-500/10 border border-sky-500/20
                            flex items-center justify-center text-sky-400 text-lg font-bold">
              {player.name.charAt(0)}
            </div>
            <div>
              <h2 className="text-base font-bold text-white">{player.name}</h2>
              <div className="flex items-center gap-2 mt-0.5">
                <StatusBadge status={player.status} />
                {player.vipLevel > 0 && (
                  <span className="text-xs text-yellow-400">VIP Nível {player.vipLevel}</span>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onBlacklist(player)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors
                ${player.isBlacklisted
                  ? 'bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20'
                  : 'bg-red-500/10 text-red-400 hover:bg-red-500/20'}`}
            >
              <Ban size={13} />
              {player.isBlacklisted ? 'Remover Blacklist' : 'Blacklist'}
            </button>
            <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors ml-2">
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Info grid */}
        <div className="px-6 py-4 border-b border-[#1e2d42] grid grid-cols-2 gap-4 flex-shrink-0">
          <div>
            <p className="text-xs text-slate-500 mb-1">Telefone</p>
            <p className="text-sm text-white flex items-center gap-1.5">
              <Phone size={13} className="text-slate-500" />
              {player.phone || '—'}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1">Grupo</p>
            <p className="text-sm text-white flex items-center gap-1.5">
              <Users size={13} className="text-slate-500" />
              {player.groupName || 'Sem grupo'}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1">Total Depósitos</p>
            <p className="text-sm font-bold text-emerald-400">{formatCurrency(player.deposit || 0)}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1">Total Saques</p>
            <p className="text-sm font-bold text-red-400">{formatCurrency(player.withdrawal || 0)}</p>
          </div>
        </div>

        {/* Tabs: In Group / Out Group */}
        <div className="flex border-b border-[#1e2d42] flex-shrink-0">
          <button
            onClick={() => setTab('in')}
            className={`flex-1 py-3 text-xs font-medium transition-colors
              ${tab === 'in' ? 'text-sky-400 border-b-2 border-sky-500' : 'text-slate-500 hover:text-slate-300'}`}
          >
            No Grupo
          </button>
          <button
            onClick={() => setTab('out')}
            className={`flex-1 py-3 text-xs font-medium transition-colors
              ${tab === 'out' ? 'text-sky-400 border-b-2 border-sky-500' : 'text-slate-500 hover:text-slate-300'}`}
          >
            Fora do Grupo
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          {tab === 'in' ? (
            <div className="space-y-3">
              <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Histórico de Transferências</p>
              {/* Mock transfers */}
              {[
                { type: 'deposit', amount: player.deposit || 0, date: new Date() },
                { type: 'withdrawal', amount: player.withdrawal || 0, date: new Date() },
              ].filter(t => t.amount > 0).map((t, i) => (
                <div key={i} className="flex items-center justify-between bg-[#1a2535] rounded-lg px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold
                      ${t.type === 'deposit' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>
                      {t.type === 'deposit' ? '+' : '-'}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-white">
                        {t.type === 'deposit' ? 'Depósito' : 'Saque'}
                      </p>
                      <p className="text-xs text-slate-500">{formatDateTime(t.date)}</p>
                    </div>
                  </div>
                  <span className={`text-sm font-bold ${t.type === 'deposit' ? 'text-emerald-400' : 'text-red-400'}`}>
                    {t.type === 'deposit' ? '+' : '-'}{formatCurrency(t.amount)}
                  </span>
                </div>
              ))}
              {(player.deposit === 0 && player.withdrawal === 0) && (
                <p className="text-center text-slate-500 py-8 text-sm">Nenhuma transferência encontrada</p>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Histórico de Contatos</p>
              <div className="bg-[#1a2535] rounded-lg px-4 py-3 flex items-start gap-3">
                <FileText size={14} className="text-slate-500 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-slate-300">Nenhum contato registrado fora do grupo.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── BLACKLIST MODAL ──────────────────────────────────────────────────────────
function BlacklistModal({
  player,
  onClose,
  onConfirm
}: {
  player: any
  onClose: () => void
  onConfirm: (note: string) => void
}) {
  const [note, setNote] = useState('')
  const isRemoving = player.isBlacklisted

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-[#111827] border border-[#1e2d42] rounded-2xl w-full max-w-sm shadow-2xl p-6">
        <div className="text-center mb-5">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3
            ${isRemoving ? 'bg-emerald-500/10 border border-emerald-500/20' : 'bg-red-500/10 border border-red-500/20'}`}>
            <Ban size={20} className={isRemoving ? 'text-emerald-400' : 'text-red-400'} />
          </div>
          <h3 className="text-base font-semibold text-white">
            {isRemoving ? 'Remover da Lista Negra' : 'Adicionar à Lista Negra'}
          </h3>
          <p className="text-slate-400 text-sm mt-1">
            Jogador: <strong className="text-white">{player.name}</strong>
          </p>
        </div>

        {!isRemoving && (
          <div className="mb-5">
            <label className="block text-sm font-medium text-slate-300 mb-1.5">
              Motivo <span className="text-slate-500 font-normal">(opcional)</span>
            </label>
            <textarea
              value={note}
              onChange={e => setNote(e.target.value)}
              rows={3}
              placeholder="Descreva o motivo..."
              className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg px-3 py-2.5
                         text-sm text-white placeholder:text-slate-500 focus:outline-none
                         focus:ring-2 focus:ring-red-500 resize-none"
            />
          </div>
        )}

        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 bg-[#1a2535] hover:bg-[#243044] text-slate-300 font-medium py-2.5 rounded-lg transition-colors text-sm"
          >
            Cancelar
          </button>
          <button
            onClick={() => onConfirm(note)}
            className={`flex-1 text-white font-medium py-2.5 rounded-lg transition-colors text-sm
              ${isRemoving ? 'bg-emerald-500 hover:bg-emerald-600' : 'bg-red-500 hover:bg-red-600'}`}
          >
            {isRemoving ? 'Remover' : 'Confirmar'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── COLUMN SETTINGS MODAL ────────────────────────────────────────────────────
function ColumnSettingsModal({
  visibleCols,
  onToggle,
  onClose
}: {
  visibleCols: string[]
  onToggle: (key: string) => void
  onClose: () => void
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-end p-4 pt-20 pr-6">
      <div className="absolute inset-0" onClick={onClose} />
      <div className="relative bg-[#111827] border border-[#1e2d42] rounded-xl w-56 shadow-2xl p-4">
        <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Colunas Visíveis</p>
        {ALL_COLUMNS.map(col => (
          <label key={col.key} className="flex items-center gap-3 py-1.5 cursor-pointer group">
            <input
              type="checkbox"
              checked={col.always || visibleCols.includes(col.key)}
              disabled={col.always}
              onChange={() => !col.always && onToggle(col.key)}
              className="w-4 h-4 accent-sky-500 cursor-pointer"
            />
            <span className={`text-sm ${col.always ? 'text-slate-500' : 'text-slate-300 group-hover:text-white'}`}>
              {col.label}
            </span>
          </label>
        ))}
      </div>
    </div>
  )
}

// ─── MAIN COMPONENT ───────────────────────────────────────────────────────────
export default function PlayersClient() {
  const [players, setPlayers] = useState<any[]>(mockPlayers)
  const [loading, setLoading] = useState(false)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [visibleCols, setVisibleCols] = useState(
    ALL_COLUMNS.filter(c => c.default || c.always).map(c => c.key)
  )
  const [colSettings, setColSettings] = useState(false)
  const [modalOpen, setModalOpen] = useState(false)
  const [editPlayer, setEditPlayer] = useState<any | null>(null)
  const [detailPlayer, setDetailPlayer] = useState<any | null>(null)
  const [blacklistPlayer, setBlacklistPlayer] = useState<any | null>(null)
  const [success, setSuccess] = useState('')

  const { register, handleSubmit, reset, formState: { errors } } = useForm<PlayerForm>({
    resolver: zodResolver(playerSchema),
    defaultValues: { vipLevel: 0, status: 'active' },
  })

  const filtered = players.filter(p => {
    const matchSearch = !search ||
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      (p.phone && p.phone.includes(search))
    const matchStatus = !statusFilter || p.status === statusFilter
    return matchSearch && matchStatus
  })

  function openCreate() {
    setEditPlayer(null)
    reset({ status: 'active', vipLevel: 0 })
    setModalOpen(true)
  }

  function openEdit(player: any) {
    setEditPlayer(player)
    reset({ name: player.name, phone: player.phone || '', status: player.status, vipLevel: player.vipLevel })
    setModalOpen(true)
  }

  function onSubmit(data: PlayerForm) {
    if (editPlayer) {
      setPlayers(ps => ps.map(p => p.id === editPlayer.id ? { ...p, ...data } : p))
      setSuccess('Jogador atualizado!')
    } else {
      const newPlayer = {
        ...data,
        id: String(Date.now()),
        isBlacklisted: false,
        deposit: 0,
        withdrawal: 0,
        groupName: null,
        consultant: null,
      }
      setPlayers(ps => [newPlayer, ...ps])
      setSuccess('Jogador criado!')
    }
    setModalOpen(false)
    setTimeout(() => setSuccess(''), 3000)
  }

  function handleBlacklistConfirm(note: string) {
    if (!blacklistPlayer) return
    setPlayers(ps => ps.map(p =>
      p.id === blacklistPlayer.id
        ? {
            ...p,
            isBlacklisted: !p.isBlacklisted,
            status: !p.isBlacklisted ? 'blacklisted' : 'inactive',
            blacklistNote: note,
          }
        : p
    ))
    setBlacklistPlayer(null)
    setSuccess(blacklistPlayer.isBlacklisted ? 'Jogador removido da lista negra!' : 'Jogador adicionado à lista negra!')
    setTimeout(() => setSuccess(''), 3000)
  }

  function toggleCol(key: string) {
    setVisibleCols(prev =>
      prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key]
    )
  }

  function handleDelete(id: string) {
    setPlayers(ps => ps.filter(p => p.id !== id))
    setSuccess('Jogador excluído!')
    setTimeout(() => setSuccess(''), 3000)
  }

  return (
    <div className="space-y-6 max-w-7xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Jogadores</h1>
          <p className="text-slate-500 text-sm mt-1">{players.length} jogadores cadastrados</p>
        </div>
        <button onClick={openCreate} className="tsm-btn-primary">
          <Plus size={16} /> Adicionar Jogador
        </button>
      </div>

      {success && (
        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg px-4 py-3 text-emerald-400 text-sm flex items-center gap-2">
          <CheckCircle size={16} /> {success}
        </div>
      )}

      {/* Table card */}
      <div className="bg-[#111827] border border-[#1e2d42] rounded-xl overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#1e2d42] gap-3 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="relative w-60">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Buscar jogadores..."
                className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg pl-9 pr-3 py-2
                           text-sm text-white placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
              />
            </div>
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="bg-[#1a2535] border border-[#1e2d42] rounded-lg px-3 py-2 text-sm
                         text-slate-300 focus:outline-none focus:ring-1 focus:ring-sky-500"
            >
              {STATUS_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <button
                onClick={() => setColSettings(!colSettings)}
                className="tsm-btn-ghost"
                title="Configurar colunas"
              >
                <Settings2 size={15} /> Colunas
              </button>
              {colSettings && (
                <ColumnSettingsModal
                  visibleCols={visibleCols}
                  onToggle={toggleCol}
                  onClose={() => setColSettings(false)}
                />
              )}
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#1e2d42]">
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider w-10">#</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Nome</th>
                {visibleCols.includes('phone') && (
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Telefone</th>
                )}
                {visibleCols.includes('status') && (
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                )}
                {visibleCols.includes('vipLevel') && (
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">VIP</th>
                )}
                {visibleCols.includes('group') && (
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Grupo</th>
                )}
                {visibleCols.includes('consultant') && (
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Consultor</th>
                )}
                {visibleCols.includes('deposit') && (
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Depósito</th>
                )}
                {visibleCols.includes('withdrawal') && (
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Saque</th>
                )}
                <th className="px-4 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={10} className="text-center py-12 text-slate-500">Nenhum jogador encontrado</td>
                </tr>
              ) : (
                filtered.map((player, i) => (
                  <tr key={player.id} className={`border-b border-[#1e2d42]/50 hover:bg-[#1a2535]/30 transition-colors
                    ${player.isBlacklisted ? 'opacity-60' : ''}`}>
                    <td className="px-4 py-3 text-slate-500 text-xs">{i + 1}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-[#1a2535] border border-[#1e2d42]
                                        flex items-center justify-center text-xs font-bold text-sky-400">
                          {player.name.charAt(0)}
                        </div>
                        <span className="text-sm font-medium text-white">{player.name}</span>
                        {player.isBlacklisted && <Ban size={12} className="text-red-400" />}
                      </div>
                    </td>
                    {visibleCols.includes('phone') && (
                      <td className="px-4 py-3 text-slate-400 text-sm">{player.phone || '—'}</td>
                    )}
                    {visibleCols.includes('status') && (
                      <td className="px-4 py-3"><StatusBadge status={player.status} /></td>
                    )}
                    {visibleCols.includes('vipLevel') && (
                      <td className="px-4 py-3">
                        {player.vipLevel > 0
                          ? <span className="text-yellow-400 text-sm font-medium">Nível {player.vipLevel}</span>
                          : <span className="text-slate-600">—</span>
                        }
                      </td>
                    )}
                    {visibleCols.includes('group') && (
                      <td className="px-4 py-3 text-slate-400 text-sm">{player.groupName || '—'}</td>
                    )}
                    {visibleCols.includes('consultant') && (
                      <td className="px-4 py-3 text-slate-400 text-sm">{player.consultant || '—'}</td>
                    )}
                    {visibleCols.includes('deposit') && (
                      <td className="px-4 py-3 text-emerald-400 text-sm font-medium">
                        {player.deposit > 0 ? formatCurrency(player.deposit) : '—'}
                      </td>
                    )}
                    {visibleCols.includes('withdrawal') && (
                      <td className="px-4 py-3 text-red-400 text-sm font-medium">
                        {player.withdrawal > 0 ? formatCurrency(player.withdrawal) : '—'}
                      </td>
                    )}
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setDetailPlayer(player)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-sky-400 hover:bg-sky-500/10 transition-colors"
                          title="Ver detalhes"
                        >
                          <Eye size={15} />
                        </button>
                        <button
                          onClick={() => openEdit(player)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 transition-colors"
                          title="Editar"
                        >
                          <Pencil size={15} />
                        </button>
                        <button
                          onClick={() => setBlacklistPlayer(player)}
                          className={`p-1.5 rounded-lg transition-colors
                            ${player.isBlacklisted
                              ? 'text-emerald-400 hover:bg-emerald-500/10'
                              : 'text-slate-400 hover:text-red-400 hover:bg-red-500/10'}`}
                          title={player.isBlacklisted ? 'Remover blacklist' : 'Blacklist'}
                        >
                          <Ban size={15} />
                        </button>
                        <button
                          onClick={() => handleDelete(player.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                          title="Excluir"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="px-5 py-3 border-t border-[#1e2d42] text-xs text-slate-500">
          {filtered.length} de {players.length} jogadores
        </div>
      </div>

      {/* ── CREATE/EDIT MODAL ─────────────────────────────────────────────────── */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setModalOpen(false)} />
          <div className="relative bg-[#111827] border border-[#1e2d42] rounded-2xl w-full max-w-md shadow-2xl">
            <div className="flex items-center justify-between px-6 py-5 border-b border-[#1e2d42]">
              <h2 className="text-base font-semibold text-white">
                {editPlayer ? 'Editar Jogador' : 'Novo Jogador'}
              </h2>
              <button onClick={() => setModalOpen(false)} className="text-slate-500 hover:text-white transition-colors">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleSubmit(onSubmit)} className="px-6 py-5 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1.5">Nome</label>
                <input {...register('name')} placeholder="Nome completo"
                  className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg px-3 py-2.5 text-sm text-white
                             placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500" />
                {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name.message}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1.5">Telefone</label>
                <input {...register('phone')} placeholder="+55 11 99999-0000"
                  className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg px-3 py-2.5 text-sm text-white
                             placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1.5">Status</label>
                  <select {...register('status')}
                    className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg px-3 py-2.5 text-sm
                               text-white focus:outline-none focus:ring-2 focus:ring-sky-500">
                    <option value="active">Ativo</option>
                    <option value="vip">VIP</option>
                    <option value="inactive">Inativo</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1.5">Nível VIP</label>
                  <input {...register('vipLevel', { valueAsNumber: true })} type="number" min={0} max={10}
                    className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg px-3 py-2.5 text-sm text-white
                               focus:outline-none focus:ring-2 focus:ring-sky-500" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1.5">Notas</label>
                <textarea {...register('notes')} rows={3} placeholder="Observações..."
                  className="w-full bg-[#1a2535] border border-[#1e2d42] rounded-lg px-3 py-2.5 text-sm text-white
                             placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500 resize-none" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setModalOpen(false)}
                  className="flex-1 bg-[#1a2535] hover:bg-[#243044] text-slate-300 font-medium py-2.5 rounded-lg transition-colors text-sm">
                  Cancelar
                </button>
                <button type="submit"
                  className="flex-1 bg-sky-500 hover:bg-sky-600 text-white font-medium py-2.5 rounded-lg transition-colors text-sm">
                  {editPlayer ? 'Salvar' : 'Criar Jogador'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Detail modal */}
      {detailPlayer && (
        <PlayerDetailModal
          player={detailPlayer}
          onClose={() => setDetailPlayer(null)}
          onBlacklist={(p) => { setDetailPlayer(null); setBlacklistPlayer(p) }}
        />
      )}

      {/* Blacklist modal */}
      {blacklistPlayer && (
        <BlacklistModal
          player={blacklistPlayer}
          onClose={() => setBlacklistPlayer(null)}
          onConfirm={handleBlacklistConfirm}
        />
      )}
    </div>
  )
}
