// components/dashboard/DashboardLive.tsx
// Wraps DashboardClient and adds: data source badge + manual sync button
'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { RefreshCw, Wifi, Database, AlertCircle } from 'lucide-react'
import DashboardClient from './DashboardClient'
import type { DashboardStats } from '@/types'

interface Props {
  stats: DashboardStats
  userName: string
  userRole: string
  dataSource: 'smartico' | 'database' | 'mock'
}

const SOURCE_CONFIG = {
  smartico: {
    label: 'Live · Smartico',
    icon: Wifi,
    cls: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    dot: 'bg-emerald-400 animate-pulse',
  },
  database: {
    label: 'Local · Database',
    icon: Database,
    cls: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
    dot: 'bg-sky-400',
  },
  mock: {
    label: 'Demo · Mock Data',
    icon: AlertCircle,
    cls: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
    dot: 'bg-yellow-400',
  },
}

export default function DashboardLive({ stats, userName, userRole, dataSource }: Props) {
  const router = useRouter()
  const [syncing, setSyncing] = useState(false)
  const [syncMsg, setSyncMsg] = useState('')
  const [isPending, startTransition] = useTransition()

  const src = SOURCE_CONFIG[dataSource] || SOURCE_CONFIG.database
  const SrcIcon = src.icon

  // Manual sync: pull Smartico events into DB, then refresh page
  async function handleSync() {
    setSyncing(true)
    setSyncMsg('')
    try {
      const res = await fetch('/api/smartico/sync', { method: 'POST' })
      const json = await res.json()
      if (res.ok) {
        setSyncMsg(`✓ Sincronizado: ${json.transfersSynced} transferências, ${json.playersCreated} jogadores novos`)
        // Refresh page data
        startTransition(() => router.refresh())
      } else {
        setSyncMsg(`✗ Erro: ${json.error || 'Falha na sincronização'}`)
      }
    } catch (err: any) {
      setSyncMsg(`✗ ${err.message || 'Erro de conexão'}`)
    } finally {
      setSyncing(false)
      setTimeout(() => setSyncMsg(''), 6000)
    }
  }

  return (
    <div className="space-y-2">
      {/* Top bar: data source indicator + sync */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {/* Source badge */}
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-medium ${src.cls}`}>
            <span className={`w-2 h-2 rounded-full ${src.dot}`} />
            <SrcIcon size={12} />
            {src.label}
          </div>

          {/* Sync message */}
          {syncMsg && (
            <span className={`text-xs font-medium ${syncMsg.startsWith('✓') ? 'text-emerald-400' : 'text-red-400'}`}>
              {syncMsg}
            </span>
          )}
        </div>

        {/* Sync button — admins/managers only */}
        {['superadmin', 'admin', 'manager'].includes(userRole) && (
          <button
            onClick={handleSync}
            disabled={syncing || isPending}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#111827] border border-[#1e2d42]
                       text-slate-400 hover:text-white hover:border-sky-500/50 transition-all text-xs font-medium
                       disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <RefreshCw size={13} className={syncing || isPending ? 'animate-spin' : ''} />
            {syncing ? 'Sincronizando...' : 'Sincronizar Smartico'}
          </button>
        )}
      </div>

      {/* Main dashboard */}
      <DashboardClient stats={stats} userName={userName} />
    </div>
  )
}
