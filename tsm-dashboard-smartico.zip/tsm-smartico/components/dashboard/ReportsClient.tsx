// components/dashboard/ReportsClient.tsx
'use client'

import { useState } from 'react'
import { Download, BarChart2, TrendingUp, Calendar } from 'lucide-react'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, LineChart, Line, Legend, PieChart, Pie, Cell
} from 'recharts'
import { formatCurrency } from '@/lib/utils'
import { mockReports } from '@/lib/mock-data'

const COLORS = ['#0ea5e9', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6']

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-[#1a2535] border border-[#1e2d42] rounded-lg px-4 py-3 shadow-xl">
      <p className="text-xs font-bold text-white mb-2">{label}</p>
      {payload.map((entry: any) => (
        <p key={entry.name} className="text-xs" style={{ color: entry.color }}>
          {entry.name}: {formatCurrency(entry.value)}
        </p>
      ))}
    </div>
  )
}

export default function ReportsClient() {
  const [period, setPeriod] = useState<'monthly' | 'weekly'>('monthly')
  const [view, setView] = useState<'chart' | 'group'>('chart')

  const totalDeposits = mockReports.monthly.reduce((s, m) => s + m.deposits, 0)
  const totalWithdrawals = mockReports.monthly.reduce((s, m) => s + m.withdrawals, 0)
  const totalProfit = mockReports.monthly.reduce((s, m) => s + m.profit, 0)

  return (
    <div className="space-y-6 max-w-6xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Relatórios</h1>
          <p className="text-slate-500 text-sm mt-1">Relatório de performance — {new Date().getFullYear()}</p>
        </div>
        <button className="tsm-btn-primary">
          <Download size={16} /> Exportar
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-[#111827] border border-[#1e2d42] rounded-xl p-5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Total Depósitos (Ano)</p>
              <p className="text-2xl font-bold text-emerald-400">{formatCurrency(totalDeposits)}</p>
            </div>
            <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/20
                            flex items-center justify-center">
              <TrendingUp size={16} className="text-emerald-400" />
            </div>
          </div>
        </div>
        <div className="bg-[#111827] border border-[#1e2d42] rounded-xl p-5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Total Saques (Ano)</p>
              <p className="text-2xl font-bold text-red-400">{formatCurrency(totalWithdrawals)}</p>
            </div>
            <div className="w-9 h-9 rounded-lg bg-red-500/10 border border-red-500/20
                            flex items-center justify-center">
              <BarChart2 size={16} className="text-red-400" />
            </div>
          </div>
        </div>
        <div className="bg-[#111827] border border-[#1e2d42] rounded-xl p-5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Lucro Líquido (Ano)</p>
              <p className="text-2xl font-bold text-sky-400">{formatCurrency(totalProfit)}</p>
            </div>
            <div className="w-9 h-9 rounded-lg bg-sky-500/10 border border-sky-500/20
                            flex items-center justify-center">
              <Calendar size={16} className="text-sky-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Toggle */}
      <div className="flex gap-2">
        {(['chart', 'group'] as const).map(v => (
          <button
            key={v}
            onClick={() => setView(v)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors
              ${view === v
                ? 'bg-sky-500 text-white'
                : 'bg-[#111827] border border-[#1e2d42] text-slate-400 hover:text-white'}`}
          >
            {v === 'chart' ? 'Gráfico Mensal' : 'Por Grupo'}
          </button>
        ))}
      </div>

      {view === 'chart' && (
        <div className="bg-[#111827] border border-[#1e2d42] rounded-xl p-5">
          <h3 className="text-sm font-semibold text-white mb-5">Performance Mensal — Depósitos vs Saques vs Lucro</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={mockReports.monthly} barSize={20} barGap={4}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e2d42" vertical={false} />
              <XAxis dataKey="month" stroke="#64748b" tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis stroke="#64748b" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false}
                tickFormatter={v => `R$${(v / 1000).toFixed(0)}k`} />
              <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
              <Legend formatter={v => <span style={{ color: '#94a3b8', fontSize: 12 }}>{v}</span>} />
              <Bar dataKey="deposits" name="Depósitos" fill="#22c55e" radius={[4, 4, 0, 0]} />
              <Bar dataKey="withdrawals" name="Saques" fill="#ef4444" radius={[4, 4, 0, 0]} />
              <Bar dataKey="profit" name="Lucro" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {view === 'group' && (
        <>
          {/* Group performance table */}
          <div className="bg-[#111827] border border-[#1e2d42] rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-[#1e2d42]">
              <h3 className="text-sm font-semibold text-white">Performance por Grupo</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-[#1e2d42]">
                    <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Grupo</th>
                    <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Jogadores</th>
                    <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Depósitos</th>
                    <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Saques</th>
                    <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Lucro</th>
                    <th className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">% Lucro</th>
                  </tr>
                </thead>
                <tbody>
                  {mockReports.byGroup.map((g, i) => {
                    const pct = g.deposits > 0 ? ((g.profit / g.deposits) * 100).toFixed(1) : '0'
                    return (
                      <tr key={i} className="border-b border-[#1e2d42]/50 hover:bg-[#1a2535]/30 transition-colors">
                        <td className="px-5 py-4">
                          <div className="flex items-center gap-3">
                            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                            <span className="font-medium text-white">{g.group}</span>
                          </div>
                        </td>
                        <td className="px-5 py-4 text-slate-400">{g.playerCount}</td>
                        <td className="px-5 py-4 text-emerald-400 font-medium">{formatCurrency(g.deposits)}</td>
                        <td className="px-5 py-4 text-red-400 font-medium">{formatCurrency(g.withdrawals)}</td>
                        <td className="px-5 py-4 text-sky-400 font-bold">{formatCurrency(g.profit)}</td>
                        <td className="px-5 py-4">
                          <div className="flex items-center gap-2">
                            <div className="flex-1 h-1.5 bg-[#1e2d42] rounded-full overflow-hidden w-16">
                              <div className="h-full bg-sky-500 rounded-full" style={{ width: `${Math.min(parseFloat(pct), 100)}%` }} />
                            </div>
                            <span className="text-slate-400 text-xs">{pct}%</span>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
                <tfoot>
                  <tr className="bg-[#0f1623] border-t border-[#1e2d42]">
                    <td className="px-5 py-4 text-white font-bold uppercase text-xs">Total</td>
                    <td className="px-5 py-4 text-slate-300 font-bold">
                      {mockReports.byGroup.reduce((s, g) => s + g.playerCount, 0)}
                    </td>
                    <td className="px-5 py-4 text-emerald-400 font-bold">{formatCurrency(totalDeposits)}</td>
                    <td className="px-5 py-4 text-red-400 font-bold">{formatCurrency(totalWithdrawals)}</td>
                    <td className="px-5 py-4 text-sky-400 font-bold">{formatCurrency(totalProfit)}</td>
                    <td className="px-5 py-4" />
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Pie chart */}
          <div className="bg-[#111827] border border-[#1e2d42] rounded-xl p-5">
            <h3 className="text-sm font-semibold text-white mb-5">Distribuição por Grupo</h3>
            <div className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={mockReports.byGroup}
                    dataKey="deposits"
                    nameKey="group"
                    cx="50%"
                    cy="50%"
                    outerRadius={90}
                    paddingAngle={3}
                    label={({ group, percent }: any) => `${group} ${(percent * 100).toFixed(0)}%`}
                    labelLine={{ stroke: '#334155' }}
                  >
                    {mockReports.byGroup.map((_, i) => (
                      <Cell key={i} fill={COLORS[i % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v: any) => formatCurrency(v)} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
