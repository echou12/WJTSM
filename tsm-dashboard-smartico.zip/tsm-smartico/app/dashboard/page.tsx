// app/dashboard/page.tsx
// Dashboard: fetches live stats from Smartico via API route
// Falls back to local DB data if Smartico is unavailable

import { auth } from '@/lib/auth'
import { redirect } from 'next/navigation'
import DashboardLive from '@/components/dashboard/DashboardLive'

export const dynamic = 'force-dynamic' // Always fresh — no caching

export default async function DashboardPage() {
  const session = await auth()
  if (!session) redirect('/login')

  // Fetch stats server-side (includes Smartico live data)
  let stats: any = null
  let dataSource = 'database'

  try {
    // Use absolute URL for server-side fetch in Next.js
    const baseUrl = process.env.NEXTAUTH_URL || 'http://localhost:3000'
    const res = await fetch(`${baseUrl}/api/dashboard/stats`, {
      headers: { Cookie: '' }, // Server-side: auth handled by session
      cache: 'no-store',
    })
    if (res.ok) {
      const json = await res.json()
      stats = json.data
      dataSource = json.source || 'database'
    }
  } catch (err) {
    console.error('[Dashboard page] Failed to fetch stats:', err)
  }

  // Fallback to mock data if both Smartico and DB fail
  if (!stats) {
    const { mockDashboardStats } = await import('@/lib/mock-data')
    stats = mockDashboardStats
    dataSource = 'mock'
  }

  return (
    <DashboardLive
      stats={stats}
      userName={session.user.name || 'Usuário'}
      userRole={session.user.role}
      dataSource={dataSource as 'smartico' | 'database' | 'mock'}
    />
  )
}
